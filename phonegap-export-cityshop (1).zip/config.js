define( function ( require ) {

	"use strict";

	return {
		app_slug : 'cityshop',
		wp_ws_url : 'http://www.cityshop.tn/wp-appkit-api/cityshop',
		wp_url : 'http://www.cityshop.tn',
		theme : 'q-android',
		version : '',
		app_title : 'CityShop',
		app_platform : 'android',
		gmt_offset : 1,
		debug_mode : 'off',
		auth_key : '0B6av-Tqohnx.~)^MCPW_JK~R*=Gu(C,A)>[4NB~%Gq*OeqV@+7/-+w0+fxWMOnC',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
